package binus.ac.id.calculatebmi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText beratBadanIsi,tinggiBadanIsi;
    Button hitung;
    TextView hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        beratBadanIsi = findViewById(R.id.beratBadanIsi);
        tinggiBadanIsi = findViewById(R.id.tinggiBadanIsi);
        hasil = findViewById(R.id.hasil);
        hitung = findViewById(R.id.hitung);

        hitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double  beratB = Double.parseDouble(beratBadanIsi.getText().toString());
                double tinggiB = Double.parseDouble(tinggiBadanIsi.getText().toString());

                double Berat = beratB;
                double Tinggi = tinggiB / 100;

                double BMI = Berat / (Tinggi * Tinggi);

                hasil.setText(Double.toString(BMI));
            }
        });
    }

}
